experience_data <- read.csv("HCAHPS - Hospital.csv")
View(experience_data)
experience_data <- experience_data[,c(1:9,16,17)]


experience_data$HCAHPS.Linear.Mean.Value[ experience_data$HCAHPS.Linear.Mean.Value == "Not Available" ] <- NA
experience_data$Number.of.Completed.Surveys[experience_data$Number.of.Completed.Surveys == "Not Available"] <- NA

#lets calculate the score 
table <- experience_data[,1:8]
table <- table[which(!duplicated(table)),]
score_mean <- experience_data[,c(1,9,10)]
denominator_survey <- experience_data[,c(1,9,11)]

score_mean_wide <- spread(score_mean,HCAHPS.Measure.ID,HCAHPS.Linear.Mean.Value)
denominator_survey_wide <- spread(denominator_survey, HCAHPS.Measure.ID, Number.of.Completed.Surveys)

score_mean_wide <- score_mean_wide[,c(1,5,8,13,18,23,28,32,38,44,49,53)]
denominator_survey_wide <- denominator_survey_wide[,c(1,5,8,13,18,23,28,32,38,44,49,53)]

data_1 <- merge(score_mean_wide,denominator_survey_wide,by="Provider.ID",suffixes=c("_mean","_total"))
experience_data_final <- merge(table,data_1,by="Provider.ID")
experience_score<-experience_data_final[,c(1,9:19)]

write.csv(experience_score, "experience.csv")


# experience: It measures cleanliness, how well the nurses/doctors communicate,
# quietness etc. Thus, higher score is better here.
experience <- read.csv("experience.csv")
experience <- experience[, -1]

sapply(experience, function(x) length(which(x == "Not Available")))


# create a function to standardise such that higher score indicates
# better quality
standardise_positive <- function(vector){
  return( ( vector - mean(vector, na.rm = T) )/(sd(vector, na.rm = T)) )
}

experience[, 2:ncol(experience)] <- sapply(experience[, -1], standardise_positive)


write.csv(experience,"experience_clean.csv")
          
        
          